using UnityEngine;
using System.Collections;

public class ScreenFlashManager : MonoBehaviour {
    public CanvasGroup FlashLayer;
    public void FlashWhite(float duration = 0.25f) { StartCoroutine(RunFlash(duration)); }
    private IEnumerator RunFlash(float duration) {
        if (FlashLayer == null) yield break;
        FlashLayer.alpha = 0f;
        float t = 0f;
        while (t < 0.08f) { t += Time.deltaTime; FlashLayer.alpha = Mathf.Lerp(0f, 1f, t/0.08f); yield return null; }
        FlashLayer.alpha = 1f; yield return new WaitForSeconds(Mathf.Max(0.05f, duration - 0.08f)); t = 0f;
        while (t < 0.08f) { t += Time.deltaTime; FlashLayer.alpha = Mathf.Lerp(1f, 0f, t/0.08f); yield return null; }
        FlashLayer.alpha = 0f;
    }
}

using UnityEngine; using System.Collections;

public class BoatTransition : MonoBehaviour {
    public CCTVManager cctvMgr; public ScreenFlashManager flash; public ChapterManager chapterMgr;
    void OnTriggerEnter(Collider other) {
        if (other.CompareTag("BoatTrigger")) { StartCoroutine(Transition()); }
    }
    IEnumerator Transition() {
        if (flash != null) flash.FlashWhite(0.25f);
        yield return new WaitForSeconds(0.35f);
        if (cctvMgr != null) cctvMgr.StartCCTVWatch();
        yield return new WaitForSeconds(15f);
        if (chapterMgr != null) chapterMgr.LoadChapter2();
    }
}

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CCTVManager : MonoBehaviour {
    public Camera FPVCam; public Camera CCTVCam; public RenderTexture BoatRT; public RawImage CCTVPanel; public float duration = 15f; public PlayerController player;
    public void StartCCTVWatch() { StartCoroutine(RunCCTV()); }
    private IEnumerator RunCCTV() {
        if (player != null) player.CanMove = false;
        if (FPVCam) FPVCam.enabled = false;
        if (CCTVCam) CCTVCam.enabled = true;
        if (CCTVPanel) CCTVPanel.texture = BoatRT;
        yield return new WaitForSeconds(duration);
        if (FPVCam) FPVCam.enabled = true; if (CCTVCam) CCTVCam.enabled = false; if (CCTVPanel) CCTVPanel.texture = null; if (player != null) player.CanMove = true;
    }
}

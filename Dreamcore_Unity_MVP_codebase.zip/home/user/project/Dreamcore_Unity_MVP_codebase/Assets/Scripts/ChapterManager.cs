using UnityEngine; using UnityEngine.SceneManagement;

public class ChapterManager : MonoBehaviour {
    public void LoadChapter2() { SceneManager.LoadScene("Chapter2"); }
}

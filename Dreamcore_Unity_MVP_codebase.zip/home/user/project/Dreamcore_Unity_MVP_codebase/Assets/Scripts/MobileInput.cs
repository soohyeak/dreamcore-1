using UnityEngine;

public static class MobileInput {
    public static Vector2 GetMove() {
#if UNITY_STANDALONE || UNITY_EDITOR
        return new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));
#else
        return Vector2.zero;
#endif
    }

    public static Vector2 GetLook() {
#if UNITY_STANDALONE || UNITY_EDITOR
        return new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
#else
        return Vector2.zero;
#endif
    }
}

using UnityEngine; using UnityEngine.Playables;

public class WakeCutsceneManager : MonoBehaviour {
    public PlayableDirector director; public void PlayWakeCutscene() { if (director != null) director.Play(); }
}

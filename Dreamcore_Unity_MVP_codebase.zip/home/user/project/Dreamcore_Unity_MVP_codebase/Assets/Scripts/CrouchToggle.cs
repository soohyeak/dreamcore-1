using UnityEngine;

public class CrouchToggle : MonoBehaviour {
    public UnityEngine.CharacterController cc; public float standHeight = 2f; public float crouchHeight = 1f; private bool isCrouching = false;
    public void Toggle() { if (cc == null) return; isCrouching = !isCrouching; cc.height = isCrouching ? crouchHeight : standHeight; Vector3 c = cc.center; c.y = isCrouching ? 0.5f : 1f; cc.center = c; }
}
